<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Quiz extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'title',
        'file_path',
        'total_questions',
        'sections_config',
        'ai_response',
    ];

    protected $casts = [
        'sections_config' => 'array',
        'ai_response' => 'array',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}