<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SecurityHeaders
{
    /**
     * Add baseline security headers for OWASP hardening.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);

        if ($response instanceof Response) {
            $response->headers->set('X-Content-Type-Options', 'nosniff');
            $response->headers->set('X-Frame-Options', 'DENY');
            $response->headers->set('Referrer-Policy', 'strict-origin-when-cross-origin');
            $response->headers->set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');

            if (app()->environment('production') && $request->isSecure()) {
                $response->headers->set(
                    'Strict-Transport-Security',
                    'max-age=31536000; includeSubDomains; preload'
                );
            }

            // CSP intentionally conservative; expanded to match actual external dependencies.
            $response->headers->set(
                'Content-Security-Policy',
                "default-src 'self'; ".
                "base-uri 'self'; ".
                "form-action 'self'; ".
                "frame-ancestors 'none'; ".
                "object-src 'none'; ".
                "img-src 'self' data:; ".
                "style-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://fonts.bunny.net; ".
                "font-src 'self' https://fonts.bunny.net data:; ".
                "script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://cdn.jsdelivr.net; ".
                "connect-src 'self' https://cdn.tailwindcss.com; ".
                "upgrade-insecure-requests"

            );
        }

        return $response;
    }
}

