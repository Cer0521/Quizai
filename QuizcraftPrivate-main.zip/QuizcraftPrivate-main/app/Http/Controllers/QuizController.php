<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Quiz;

class QuizController extends Controller
{

    public function index()
    {

        $quizzes = auth()->user()->quizzes()->latest()->get();
        return view('dashboard', compact('quizzes'));
    }

    public function create()
    {
        return view('quizzes.create');
    }

    public function show(\App\Models\Quiz $quiz)
    {
        if ($quiz->user_id !== auth()->id()) {
            abort(403);
        }
        return view('quizzes.show', compact('quiz'));
    }

    public function edit(\App\Models\Quiz $quiz)
    {
        if ($quiz->user_id !== auth()->id()) {
            abort(403);
        }
        return view('quizzes.edit', compact('quiz'));
    }

    public function update(Request $request, \App\Models\Quiz $quiz)
    {
        if ($quiz->user_id !== auth()->id()) {
            abort(403);
        }

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'ai_response' => 'nullable|array',
        ]);

        $updateData = ['title' => $validated['title']];
        
        if ($request->has('ai_response') && is_array($request->input('ai_response'))) {
            $updateData['ai_response'] = $request->input('ai_response');
        }

        $quiz->update($updateData);
        return redirect()->route('quizzes.show', $quiz->id)->with('success', 'Assessment updated successfully!');
    }

    public function store(Request $request, \App\Services\GeminiApiService $geminiService)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'document' => 'required|file|mimes:pdf,txt|max:5120',
            'total_questions' => 'required|integer|min:1|max:150',
            'sections' => 'required|array|min:1',
            'sections.*.type' => 'required|string',
            'sections.*.count' => 'required|integer|min:1',
        ], [
            'document.max' => 'Document must be smaller than 5MB.',
            'document.mimes' => 'Document must be a PDF or text file.'
        ]);

        $totalAssigned = array_sum(array_column($validated['sections'], 'count'));
        if ($totalAssigned !== (int) $validated['total_questions']) {
            return back()->withErrors(['sections' => "The sections total ($totalAssigned) must equal Total Questions ({$validated['total_questions']})."])->withInput();
        }

        try {
            $file = $request->file('document');
            $mimeType = $file->getMimeType();
            $base64Data = base64_encode(file_get_contents($file->getRealPath()));
            $path = $file->store('quiz_documents');

            $quiz = auth()->user()->quizzes()->create([
                'title' => $validated['title'],
                'file_path' => $path,
                'total_questions' => $validated['total_questions'],
                'sections_config' => $validated['sections'],
            ]);

            $prompt = "You are an expert educator. Create a comprehensive assessment based ONLY on the provided document. The test must have exactly {$validated['total_questions']} questions. Follow this exact blueprint:\n\n";

            foreach ($validated['sections'] as $index => $section) {
                $sectionNum = $index + 1;
                $prompt .= "Section {$sectionNum}: {$section['count']} Questions, Format: {$section['type']}.\n";
            }

            $prompt .= "\nReturn the output STRICTLY as a JSON object with a 'sections' array. Each section must have a 'title', 'type', and an array of 'questions'. Each question must have the 'question_text', an array of 'options' (if multiple choice), and the 'correct_answer'.";
            $aiResponse = $geminiService->generateFromDocument($prompt, $mimeType, $base64Data);
            $quiz->update(['ai_response' => $aiResponse]);
            return redirect()->route('quizzes.show', $quiz->id)->with('success', 'Assessment generated successfully!');

        } catch (\Exception $e) {
            return back()->withErrors(['error' => $e->getMessage()])->withInput();
        }
    }

    public function destroy(Quiz $quiz)
    {
        if ($quiz->user_id !== auth()->id()) {
            abort(403);
        }

        if ($quiz->file_path && Storage::exists($quiz->file_path)) {
            Storage::delete($quiz->file_path);
        }

        $quiz->delete();

        return redirect()->route('dashboard')->with('success', 'Assessment deleted successfully.');
    }
}