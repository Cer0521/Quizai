<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;

class GeminiApiService
{
    protected $apiKey;
    protected $baseUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';
    public function __construct()
    {
        $this->apiKey = config('services.gemini.key');
    }

    public function generateQuiz(string $prompt)
    {
        try {
            $response = Http::withHeaders([
                'Content-Type' => 'application/json',
            ])->post($this->baseUrl . '?key=' . $this->apiKey, [
                        'contents' => [
                            [
                                'parts' => [
                                    ['text' => $prompt]
                                ]
                            ]
                        ]
                    ]);
            if ($response->successful()) {
                return $response->json();
            }
            Log::error('Gemini API request failed', ['status' => $response->status(), 'body' => $response->body()]);
            throw new Exception("The AI service is currently unavailable.");
        } catch (Exception $e) {
            Log::error('Gemini API Connection Error: ' . $e->getMessage());
            throw new Exception("An error occurred while communicating with the AI service.");
        }
    }
    public function generateFromDocument(string $prompt, string $mimeType, string $base64Data)
    {
        try {
            $response = Http::timeout(120)->withHeaders([
                'Content-Type' => 'application/json',
                'x-goog-api-key' => $this->apiKey
            ])->post($this->baseUrl, [
                        'generationConfig' => [
                            'responseMimeType' => 'application/json',
                        ],
                        'contents' => [
                            [
                                'parts' => [
                                    ['text' => $prompt],
                                    [
                                        'inlineData' => [
                                            'mimeType' => $mimeType,
                                            'data' => $base64Data
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ]);

            if ($response->successful()) {
                $aiText = $response->json('candidates.0.content.parts.0.text');
                return json_decode($aiText, true);
            }

            Log::error('Gemini API request failed', ['status' => $response->status(), 'body' => $response->body()]);

            if ($response->status() === 400) {
                throw new Exception("The document is too large or in an unsupported format. Please try a smaller or different document.");
            } elseif ($response->status() === 429) {
                throw new Exception("Too many requests. Please wait a moment and try again.");
            }

            throw new Exception("The AI service could not process this document. Please try again.");

        } catch (\Illuminate\Http\Client\ConnectionException $e) {
            Log::error('Gemini API Connection Timeout: ' . $e->getMessage());
            throw new Exception("The request took too long to process. Please try with a smaller document.");
        } catch (Exception $e) {
            Log::error('Gemini File Error: ' . $e->getMessage());
            throw $e;
        }
    }
}