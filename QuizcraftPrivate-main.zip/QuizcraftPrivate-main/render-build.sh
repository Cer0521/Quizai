#!/usr/bin/env bash
set -e

echo "Starting QuizCraft Deployment..."

php artisan config:cache
php artisan route:cache
php artisan view:cache

# Run migrations
echo "Syncing DB..."
php artisan migrate --force

echo "App is ready, Starting Apache..."
exec apache2-foreground