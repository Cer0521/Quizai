<p align="center">
 <img src="./logo.svg" alt="QuizCraft AI Logo" width="400">
</p>

<p align="center">
<a href="#"><img src="https://img.shields.io/badge/build-itworkslmao-brightgreen.svg" alt="Build Status"></a>
<a href="#"><img src="https://img.shields.io/badge/PHP-8.2%2B-blue.svg" alt="PHP Version"></a>
<a href="#"><img src="https://img.shields.io/badge/Laravel-11.x-red.svg" alt="Laravel Version"></a>
<a href="#"><img src="https://img.shields.io/badge/License-MIT-green.svg" alt="License"></a>
</p>

## About QuizCraft AI

QuizCraft AI is an automated, AI-powered assessment generation platform designed to reduce test creation time from hours to minutes. We believe the focus of educators should be on personalized teaching, not the tedious manual formulation of questions. 

Built on top of the Laravel framework, QuizCraft AI takes the pain out of assessment planning by automating complex tasks and ensuring pedagogical variety from existing dense materials (PPTs, PDFs, and DOCs). Key features include:

- **AI-Driven Question Generation**: Automatically extract and formulate factual and analytical questions.
- **Multi-Format Blueprinting**: Enforce structured, section-by-section formats (e.g., True/False, Multiple Choice, and Enumeration) for complex assessments.
- **Pedagogical Balance**: Ensure a varied cognitive load across tests without meticulous manual planning.
- **Instant Export**: Generate complete, beautifully formatted test papers (Word docs or PDFs) alongside an accompanying answer key.

QuizCraft AI is accessible, powerful, and provides the tools required by university professors, corporate trainers, and private tutors to validate learner comprehension efficiently.

## License

QuizCraft AI is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).

---

## Getting Started

These instructions will help you run QuizCraft AI on your local machine for development and testing purposes.

### Requirements

- PHP 8.2 or newer with the following extensions enabled: `openssl`, `pdo`, `mbstring`, `tokenizer`, `gd`, `xml`, `bcmath`, `ctype`, `json`, `curl`, `zip`, `fileinfo`, and `pdo_pgsql` (for PostgreSQL) or `pdo_mysql` (for MySQL).
- Composer (dependency manager for PHP)
- Node.js 20+ and npm (for building frontend assets)
- A database server (PostgreSQL is used in production; MySQL/MariaDB works too)
- Git (to clone the repository)

> **New to PHP/Laravel?**
> If you don't yet have PHP or Composer installed, follow the
> [official PHP installation guide](https://www.php.net/downloads) and
> [Composer getting started page](https://getcomposer.org/download/).
> Laravel itself is pulled in via Composer; there is no need to install a
> global `laravel` binary unless you prefer to use `laravel new` when
> creating fresh projects.  For a walkthrough from zero, the Laravel
> docs have a good [installation section](https://laravel.com/docs/11.x/installation).

### Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/yourusername/quizcraft-ai.git
   cd quizcraft-ai
   ```

2. **Install PHP dependencies:**
   ```bash
   composer install --optimize-autoloader --no-dev
   ```

3. **Install and build frontend assets:**
   ```bash
   npm install
   npm run build
   ```
   > *Note:* Tailwind CSS and Alpine.js are served via CDN in production, but you can still build optionally if customizing styles.

4. **Copy environment file and generate an application key:**
   ```bash
   cp .env.example .env
   php artisan key:generate
   ```

5. **Configure your `.env` file:**
   Ask a teammate for the `.env` values (app URL, database settings, and
   `GEMINI_API_KEY`). Those are not committed to Git, so just paste the
   contents you receive into `.env`.

6. **Run database migrations:**
   ```bash
   php artisan migrate
   ```

7. **(Optional) Seed the database:**
   ```bash
   php artisan db:seed
   ```

### Running the Application

- **Start the development server:**
  ```bash
  php artisan serve --host=127.0.0.1 --port=8000
  ```
  (Once you've completed the one‑time setup above, this is all you need to
  run the app locally – just execute `php artisan serve` from the project root)
  Open [http://127.0.0.1:8000](http://127.0.0.1:8000) in your browser.

- **Run tests:**
  ```bash
  ./vendor/bin/phpunit
  ```

### Using Docker (optional)

A `Dockerfile` is included for building a production-like image. To run the app in Docker:

1. **Build the image:**
   ```bash
   docker build -t quizcraft-ai .
   ```
2. **Run a container (example with PostgreSQL):**
   ```bash
   docker run --rm -p 8000:80 \
     -e APP_ENV=local \
     -e DB_CONNECTION=pgsql \
     -e DB_HOST=host.docker.internal \
     -e DB_PORT=5432 \
     -e DB_DATABASE=quizcraft \
     -e DB_USERNAME=postgres \
     -e DB_PASSWORD=secret \
     -e GEMINI_API_KEY=yourkey \
     quizcraft-ai
   ```
   > This will start the container and automatically run migrations before serving.

### Notes

- The web app uses Tailwind CSS via CDN and Alpine.js for light interactivity. No local asset compilation is required unless you want to modify styles.
- Upload documents (PDF, PPT, DOC) up to 5 MB for quiz generation.
- A user must register/login before creating quizzes. You can customize the auth scaffolding via Laravel's built-in features.

---


QuizCraft AI is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).