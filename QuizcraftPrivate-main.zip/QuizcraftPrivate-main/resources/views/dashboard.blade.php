<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('My Assessments') }}
            </h2>
            <a href="{{ route('quizzes.create') }}"
                class="inline-flex items-center gap-2 px-4 py-2 bg-red-600 border border-transparent rounded-md font-bold text-xs text-white uppercase tracking-widest shadow-sm hover:bg-red-700 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 active:scale-95 transition transform ease-in-out duration-150">
                <span aria-hidden="true">
                    <!-- Heroicon: plus -->
                    <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                        stroke-width="2" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                    </svg>
                </span>
                <span>Create New Assessment</span>
            </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            @if (session('success'))
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative">
                    <span class="block sm:inline">{{ session('success') }}</span>
                </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Assessment History</h3>

                    @if ($quizzes->isEmpty())
                        <div class="text-center py-8 text-gray-500">
                            <p>You haven't created any assessments yet.</p>
                            <p class="mt-2 text-sm">Click the button above to upload a document and get started!</p>
                        </div>
                    @else
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    @foreach ($quizzes as $quiz)
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $quiz->title }}</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $quiz->created_at->format('Y-m-d') }}</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                <div class="flex items-center gap-2">
                                                    <a href="{{ route('quizzes.edit', $quiz) }}"
                                                        class="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 active:scale-95 transition transform duration-150"
                                                        aria-label="Edit {{ $quiz->title }}">
                                                        <!-- Heroicon: pencil-square -->
                                                        <svg class="w-4 h-4 mr-1" xmlns="http://www.w3.org/2000/svg"
                                                            fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                                            stroke="currentColor" aria-hidden="true">
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931z" />
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                d="M19.5 7.125L16.875 4.5M18 14v4.75A1.25 1.25 0 0116.75 20H5.25A1.25 1.25 0 014 18.75V7.25A1.25 1.25 0 015.25 6H10" />
                                                        </svg>
                                                        <span class="hidden sm:inline">Edit</span>
                                                    </a>

                                                    <a href="{{ route('quizzes.show', $quiz) }}"
                                                        class="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 active:scale-95 transition transform duration-150"
                                                        aria-label="View and print {{ $quiz->title }}">
                                                        <!-- Heroicon: printer -->
                                                        <svg class="w-4 h-4 mr-1" xmlns="http://www.w3.org/2000/svg"
                                                            fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                                            stroke="currentColor" aria-hidden="true">
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                d="M6.75 7.5V4.75A1.25 1.25 0 018 3.5h8a1.25 1.25 0 011.25 1.25V7.5M6.75 16.5H5.25A1.25 1.25 0 014 15.25v-5.5A1.25 1.25 0 015.25 8.5h13.5A1.25 1.25 0 0120 9.75v5.5A1.25 1.25 0 0118.75 16.5H17.25M6.75 16.5H8m0 0h8m-8 0v2.75A1.25 1.25 0 009.25 20.5h5.5A1.25 1.25 0 0016 19.25V16.5m-8 0h8" />
                                                        </svg>
                                                        <span class="hidden sm:inline">Print</span>
                                                    </a>

                                                    <form action="{{ route('quizzes.destroy', $quiz) }}" method="POST"
                                                        onsubmit="return confirm('Are you sure you want to delete this assessment? This action cannot be undone.');">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit"
                                                            class="inline-flex items-center justify-center rounded-md border border-red-200 bg-red-50 px-2.5 py-1.5 text-xs font-semibold text-red-700 shadow-sm hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-400 active:scale-95 transition transform duration-150"
                                                            aria-label="Delete {{ $quiz->title }}">
                                                            <!-- Heroicon: trash -->
                                                            <svg class="w-4 h-4 mr-1" xmlns="http://www.w3.org/2000/svg"
                                                                fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                                                stroke="currentColor" aria-hidden="true">
                                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                                    d="M9.75 9.75v6.75M14.25 9.75v6.75M5.25 6.75h13.5M10.5 4.5h3A1.5 1.5 0 0115 6v.75H9V6a1.5 1.5 0 011.5-1.5zm-3 3h9a1 1 0 011 1v9.75A2.25 2.25 0 0115.25 21H8.75A2.25 2.25 0 016.5 18.75V8.5a1 1 0 011-1z" />
                                                            </svg>
                                                            <span class="hidden sm:inline">Delete</span>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout>