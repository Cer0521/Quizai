<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>QuizCraft AI - AI-Powered Assessment Generator</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-black text-white antialiased">
    <div class="relative min-h-screen flex flex-col">
        <!-- Hero Section -->
        <div class="relative flex-1 flex flex-col items-center justify-center overflow-hidden px-6 py-20">
            <!-- Animated Background -->
            <div
                class="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_50%,rgba(239,68,68,0.1),rgba(0,0,0,0.5))]">
            </div>

            <main class="relative z-10 text-center max-w-4xl">
                <div class="mb-6 inline-block">
                </div>

                <h1 class="text-7xl font-extrabold tracking-tight mb-6 leading-tight">
                    Quiz<span class="text-red-600">Craft</span> AI
                </h1>

                <p class="text-2xl text-gray-300 mb-4 font-light">
                    Turn documents into comprehensive assessments instantly
                </p>
                <p class="text-lg text-gray-500 mb-12 max-w-2xl mx-auto">
                    Upload your study materials, PDFs, or notes and let AI generate customized quizzes,
                    exams, and assessments tailored to your needs.
                </p>

                <div class="flex gap-4 justify-center mb-16">
                    @auth
                        <a href="{{ url('/dashboard') }}"
                            class="px-8 py-4 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition transform hover:scale-105">
                            Open Dashboard
                        </a>
                    @else
                        <a href="{{ route('login') }}"
                            class="px-8 py-4 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition transform hover:scale-105">
                            Sign In
                        </a>
                        <a href="{{ route('register') }}"
                            class="px-8 py-4 bg-transparent border-2 border-red-600 hover:bg-red-600/10 text-white font-bold rounded-lg transition">
                            Create Free Account
                        </a>
                    @endauth
                </div>

                <!-- Feature Highlights -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20 pt-12 border-t border-gray-800">
                    <div class="text-center">
                        <h3 class="text-lg font-semibold mb-2">Instant Generation</h3>
                        <p class="text-gray-400 text-sm">Create assessments in seconds, not hours</p>
                    </div>
                    <div class="text-center">
                        <h3 class="text-lg font-semibold mb-2">Fully Customizable</h3>
                        <p class="text-gray-400 text-sm">Choose question types, difficulty, and count</p>
                    </div>
                    <div class="text-center">
                        <h3 class="text-lg font-semibold mb-2">Easy to Edit</h3>
                        <p class="text-gray-400 text-sm">Refine questions and answers after generation</p>
                    </div>
                </div>
            </main>
        </div>

        <!-- Footer -->
        <footer class="relative z-10 border-t border-gray-800 py-8 text-center text-gray-500 text-sm">
            &copy; {{ date('Y') }} QuizCraft AI. All rights reserved.
        </footer>
    </div>
</body>

</html>