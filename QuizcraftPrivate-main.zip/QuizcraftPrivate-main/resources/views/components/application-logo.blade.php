<img
    src="https://via.placeholder.com/140x40?text=QuizCraft+AI"
    alt="QuizCraft AI logo"
    {{ $attributes->merge([
        'class' =>
            'h-9 w-auto rounded-md border border-gray-200 bg-white shadow-sm object-contain',
    ]) }}
>
