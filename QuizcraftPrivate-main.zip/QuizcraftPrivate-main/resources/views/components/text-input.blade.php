@props(['disabled' => false, 'type' => 'text'])

<input type="{{ $type }}" @disabled($disabled) {{ $attributes->merge(['class' => 'px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:border-red-500 focus:ring-red-500 focus:outline-none transition']) }}>