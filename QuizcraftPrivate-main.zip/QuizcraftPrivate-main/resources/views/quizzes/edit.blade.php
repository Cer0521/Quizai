<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Edit Assessment') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    @if ($errors->any())
                        <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                            <strong class="font-bold">Oops!</strong>
                            <ul class="mt-2 list-disc list-inside text-sm">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form action="{{ route('quizzes.update', $quiz->id) }}" method="POST">
                        @csrf
                        @method('PATCH')

                        <div class="mb-8">
                            <label class="block text-lg font-semibold text-gray-900 mb-2">Assessment Title</label>
                            <input type="text" name="title"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:border-red-500 focus:ring-red-500"
                                value="{{ old('title', $quiz->title) }}" required>
                        </div>

                        @if($quiz->ai_response && isset($quiz->ai_response['sections']))
                            <div class="mb-8">
                                <h3 class="text-2xl font-bold text-gray-900 mb-6">Edit Questions & Answers</h3>

                                @foreach($quiz->ai_response['sections'] as $sectionIndex => $section)
                                    <div class="mb-8 p-6 bg-gray-50 rounded-lg border border-gray-200">
                                        <h4 class="text-lg font-bold text-red-600 mb-4">
                                            {{ $section['title'] ?? $section['type'] }}
                                        </h4>

                                        @if(isset($section['questions']) && is_array($section['questions']))
                                            @foreach($section['questions'] as $qIndex => $question)
                                                <div class="mb-6 p-4 bg-white rounded border border-gray-300">
                                                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                                                        Question {{ $qIndex + 1 }}
                                                    </label>
                                                    <textarea
                                                        name="ai_response[sections][{{ $sectionIndex }}][questions][{{ $qIndex }}][question_text]"
                                                        class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:border-red-500 focus:ring-red-500 mb-4"
                                                        rows="2">{{ old("ai_response.sections.$sectionIndex.questions.$qIndex.question_text", $question['question_text'] ?? $question['question'] ?? '') }}</textarea>

                                                    @if(isset($question['options']) && is_array($question['options']))
                                                        <div class="mb-4">
                                                            <label class="block text-sm font-semibold text-gray-700 mb-2">Options</label>
                                                            @foreach($question['options'] as $oIndex => $option)
                                                                <input type="text"
                                                                    name="ai_response[sections][{{ $sectionIndex }}][questions][{{ $qIndex }}][options][{{ $oIndex }}]"
                                                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:border-red-500 focus:ring-red-500 mb-2"
                                                                    value="{{ old("ai_response.sections.$sectionIndex.questions.$qIndex.options.$oIndex", $option) }}">
                                                            @endforeach
                                                        </div>
                                                    @endif

                                                    <label class="block text-sm font-semibold text-gray-700 mb-2">Correct Answer</label>
                                                    <input type="text"
                                                        name="ai_response[sections][{{ $sectionIndex }}][questions][{{ $qIndex }}][correct_answer]"
                                                        class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:border-red-500 focus:ring-red-500"
                                                        value="{{ old("ai_response.sections.$sectionIndex.questions.$qIndex.correct_answer", $question['correct_answer'] ?? $question['answer'] ?? '') }}">
                                                </div>
                                            @endforeach
                                        @endif
                                    </div>
                                @endforeach
                            </div>
                        @endif

                        <div class="flex gap-3 pt-6 border-t">
                            <button type="submit"
                                class="inline-flex items-center px-6 py-3 bg-red-600 border border-transparent rounded-md font-bold text-sm text-white uppercase tracking-widest hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                Save Changes
                            </button>
                            <a href="{{ route('quizzes.show', $quiz->id) }}"
                                class="inline-flex items-center px-6 py-3 bg-gray-600 border border-transparent rounded-md font-bold text-sm text-white uppercase tracking-widest hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>