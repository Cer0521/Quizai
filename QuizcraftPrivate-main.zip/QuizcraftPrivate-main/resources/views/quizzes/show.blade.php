<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ $quiz->title }}
            </h2>
            <div class="flex gap-2">
                <a href="{{ route('quizzes.edit', $quiz->id) }}" class="px-4 py-2 bg-yellow-500 text-gray-900 rounded-md text-sm font-bold hover:bg-yellow-600 border border-yellow-600 shadow">
                    Edit
                </a>
                <button onclick="copyToClipboard()" class="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-bold hover:bg-blue-700 border border-blue-700 shadow">
                    Copy to Clipboard
                </button>
                <button onclick="exportAsText()" class="px-4 py-2 bg-teal-600 text-white rounded-md text-sm font-bold hover:bg-teal-700 border border-teal-700 shadow">
                    Export as Text
                </button>
                <button onclick="window.print()" class="px-4 py-2 bg-gray-800 text-white rounded-md text-sm font-bold hover:bg-gray-700 border border-gray-900 shadow">
                    Print / Save PDF
                </button>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-8" id="printable-area">
                
                <div class="text-center mb-8 border-b pb-4">
                    <h1 class="text-3xl font-bold uppercase">{{ $quiz->title }}</h1>
                    <p class="text-gray-600 mt-2">Total Questions: {{ $quiz->total_questions }}</p>
                </div>

                @if($quiz->ai_response && isset($quiz->ai_response['sections']))
                    @foreach($quiz->ai_response['sections'] as $sectionIndex => $section)
                        <div class="mb-10">
                            <h3 class="text-xl font-bold text-red-600 mb-4 uppercase">
                                {{ $section['title'] ?? $section['type'] }}
                            </h3>
                            
                            <div class="space-y-6">
                                @foreach($section['questions'] as $qIndex => $question)
                                    <div class="pl-4">
                                        <p class="font-medium text-gray-900">
                                            {{ $qIndex + 1 }}. {{ $question['question_text'] ?? $question['question'] }}
                                        </p>
                                        
                                        @if(isset($question['options']) && is_array($question['options']))
                                            <ul class="mt-2 list-none pl-4 space-y-1">
                                                @foreach($question['options'] as $option)
                                                    <li class="text-gray-700 flex items-center gap-2">
                                                        <div class="w-4 h-4 border border-gray-400 rounded-full"></div> 
                                                        {{ $option }}
                                                    </li>
                                                @endforeach
                                            </ul>
                                        @endif

                                        <div class="mt-3 inline-block bg-red-50 text-red-700 px-3 py-1 rounded text-sm font-semibold">
                                            Answer: {{ $question['correct_answer'] ?? $question['answer'] ?? 'N/A' }}
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                @else
                    <p class="text-red-500">Error: Could not parse the assessment data. The AI may have returned an invalid format.</p>
                @endif

            </div>
        </div>
    </div>

    <style>
        @media print {
            body * { visibility: hidden; }
            #printable-area, #printable-area * { visibility: visible; }
            #printable-area { position: absolute; left: 0; top: 0; width: 100%; }
            .bg-red-50 { display: none; } 
        }
    </style>

    <script>
        function formatQuestionnaireContent() {
            const title = '{{ $quiz->title }}';
            const totalQuestions = '{{ $quiz->total_questions }}';
            const aiResponse = {{ json_encode($quiz->ai_response) }};
            
            let content = `${title}\n${'='.repeat(title.length)}\n`;
            content += `Total Questions: ${totalQuestions}\n\n`;
            
            if (aiResponse && aiResponse.sections) {
                aiResponse.sections.forEach((section, sIdx) => {
                    content += `\nSECTION ${sIdx + 1}: ${section.title || section.type}\n`;
                    content += `${'─'.repeat(50)}\n\n`;
                    
                    if (section.questions) {
                        section.questions.forEach((question, qIdx) => {
                            const qNum = sIdx * 100 + qIdx + 1;
                            content += `${qNum}. ${question.question_text || question.question}\n`;
                            
                            if (question.options && Array.isArray(question.options)) {
                                question.options.forEach((option, oIdx) => {
                                    content += `   ${String.fromCharCode(65 + oIdx)}) ${option}\n`;
                                });
                            }
                            
                            content += '\n';
                        });
                    }
                });
            }
            
            return content;
        }
        
        function formatAnswerKeyContent() {
            const title = '{{ $quiz->title }}';
            const aiResponse = {{ json_encode($quiz->ai_response) }};
            
            let content = `ANSWER KEY: ${title}\n`;
            content += `${'='.repeat(30 + title.length)}\n\n`;
            
            if (aiResponse && aiResponse.sections) {
                aiResponse.sections.forEach((section, sIdx) => {
                    content += `\nSECTION ${sIdx + 1}: ${section.title || section.type}\n`;
                    content += `${'─'.repeat(50)}\n\n`;
                    
                    if (section.questions) {
                        section.questions.forEach((question, qIdx) => {
                            const qNum = sIdx * 100 + qIdx + 1;
                            content += `${qNum}. ${question.correct_answer || question.answer || 'N/A'}\n`;
                        });
                    }
                    
                    content += '\n';
                });
            }
            
            return content;
        }

        function copyToClipboard() {
            const content = formatQuestionnaireContent();
            navigator.clipboard.writeText(content).then(() => {
                alert('Assessment copied to clipboard (without answer key)!');
            }).catch(() => {
                alert('Failed to copy to clipboard');
            });
        }

        function exportAsText() {
            const questionnaire = formatQuestionnaireContent();
            const answerKey = formatAnswerKeyContent();
            
            // Download questionnaire
            const qElement = document.createElement('a');
            qElement.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(questionnaire));
            qElement.setAttribute('download', '{{ $quiz->title }}_Questionnaire.txt');
            qElement.style.display = 'none';
            document.body.appendChild(qElement);
            qElement.click();
            document.body.removeChild(qElement);
            
            // Download answer key after a short delay
            setTimeout(() => {
                const aElement = document.createElement('a');
                aElement.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(answerKey));
                aElement.setAttribute('download', '{{ $quiz->title }}_Answer_Key.txt');
                aElement.style.display = 'none';
                document.body.appendChild(aElement);
                aElement.click();
                document.body.removeChild(aElement);
            }, 500);
        }
    </script>
</x-app-layout>