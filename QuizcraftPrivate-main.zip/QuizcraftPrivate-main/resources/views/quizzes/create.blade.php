<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Create New Assessment') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 md:p-8 border border-gray-100">

                @if ($errors->any())
                    <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                        <strong class="font-bold">Oops!</strong>
                        <ul class="mt-2 list-disc list-inside text-sm">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('quizzes.store') }}" method="POST" enctype="multipart/form-data"
                    x-data="{ loading: false }" @submit="loading = true"
                    class="space-y-6">
                    @csrf

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="title" class="block text-sm font-medium text-gray-700">
                                Assessment Title
                            </label>
                            <input type="text" name="title"
                                id="title"
                                class="mt-1 block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm placeholder:text-gray-400 focus:border-[#FF2D20] focus:ring-2 focus:ring-[#FF2D20] focus:ring-offset-1 focus:ring-offset-white transition-colors duration-150"
                                required placeholder="e.g., Midterm Exam - OOP" value="{{ old('title') }}">
                            @if ($errors->has('title'))
                                <p class="text-red-600 text-sm mt-1">{{ $errors->first('title') }}</p>
                            @endif
                        </div>
                        <div>
                            <label for="document" class="block text-sm font-medium text-gray-700">
                                Upload Source Document (PDF or TXT)
                            </label>
                            <input type="file" name="document"
                                id="document"
                                class="mt-1 block w-full text-sm text-gray-600 rounded-md border border-dashed border-gray-300 bg-gray-50 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-red-50 file:text-red-600 hover:file:bg-red-100 focus:border-[#FF2D20] focus:ring-2 focus:ring-[#FF2D20] focus:ring-offset-1 focus:ring-offset-gray-50 transition-colors duration-150"
                                required accept=".pdf,.ppt,.pptx,.doc,.docx">
                            <p class="text-xs text-gray-500 mt-1">Recommended: Keep documents under 5MB for faster
                                processing.</p>
                            @if ($errors->has('document'))
                                <p class="text-red-600 text-sm mt-1">{{ $errors->first('document') }}</p>
                            @endif
                        </div>
                    </div>

                    <div x-data="quizBuilder()" class="border-t border-gray-200 pt-6 mt-4">
                        <div class="mb-6">
                            <label for="total_questions" class="block text-sm font-medium text-gray-700 mb-1">
                                Total Questions
                            </label>
                            <input type="number" name="total_questions" id="total_questions" x-model.number="total"
                                class="w-32 rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-[#FF2D20] focus:ring-2 focus:ring-[#FF2D20] focus:ring-offset-1 focus:ring-offset-white transition-colors duration-150"
                                required min="1">
                        </div>

                        <h3 class="text-lg font-medium text-gray-900 mb-4 border-b border-gray-200 pb-2">
                            Assessment Structure
                        </h3>

                        <template x-for="(section, index) in sections" :key="index">
                            <div class="flex items-center gap-4 mb-4 bg-gray-50 p-4 rounded-md border border-gray-200 transition hover:bg-gray-100">
                                <div class="font-bold text-gray-500" x-text="'Section ' + (index + 1)"></div>

                                <div class="flex-1">
                                    <select x-bind:name="'sections['+index+'][type]'" x-model="section.type"
                                        class="block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-[#FF2D20] focus:ring-2 focus:ring-[#FF2D20] focus:ring-offset-1 focus:ring-offset-gray-50 transition-colors duration-150">
                                        <option value="Multiple Choice">Multiple Choice</option>
                                        <option value="True or False">True or False</option>
                                        <option value="Enumeration">Enumeration</option>
                                    </select>
                                </div>

                                <div>
                                    <input type="number" x-bind:name="'sections['+index+'][count]'"
                                        x-model.number="section.count"
                                        class="w-24 rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-[#FF2D20] focus:ring-2 focus:ring-[#FF2D20] focus:ring-offset-1 focus:ring-offset-gray-50 transition-colors duration-150"
                                        placeholder="Qty" min="1" required>
                                </div>

                                <button type="button" @click="removeSection(index)"
                                    class="inline-flex items-center justify-center text-red-500 hover:text-red-700 focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-offset-2 rounded-full p-1 transition active:scale-95"
                                    x-show="sections.length > 1">
                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                                        </path>
                                    </svg>
                                </button>
                            </div>
                        </template>

                        <div class="mb-2 text-sm font-medium"
                            :class="remainingQuestions === 0 ? 'text-green-600' : (remainingQuestions < 0 ? 'text-red-600' : 'text-orange-500')">
                            Questions assigned: <span x-text="assignedQuestions"></span> / <span x-text="total"></span>
                            <span x-show="remainingQuestions !== 0"
                                x-text="remainingQuestions > 0 ? '(' + remainingQuestions + ' remaining)' : '(Too many assigned!)'"></span>
                        </div>

                        @if ($errors->has('sections'))
                            <p class="text-red-600 text-sm mb-4">{{ $errors->first('sections') }}</p>
                        @endif

                        <button type="button" @click="addSection"
                            class="mb-6 inline-flex items-center px-4 py-2 bg-gray-900 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest shadow-sm hover:bg-gray-800 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-gray-700 focus:ring-offset-2 active:scale-95 transition transform duration-150">
                            + Add Section
                        </button>
                    </div>

                    <div class="border-t border-gray-200 pt-4 flex justify-end">
                        <button type="submit" :disabled="loading"
                            class="inline-flex items-center px-6 py-3 bg-red-600 border border-transparent rounded-md font-bold text-sm text-white uppercase tracking-widest shadow-sm hover:bg-red-700 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 active:scale-95 transition transform ease-in-out duration-150 disabled:opacity-50 disabled:cursor-not-allowed">
                            <span x-show="!loading" x-cloak>Generate Quiz</span>
                            <span x-show="loading" x-cloak class="flex items-center" style="display: none;">
                                <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                                    xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor"
                                        stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor"
                                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z">
                                    </path>
                                </svg>
                                Generating... (This may take a minute)
                            </span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function quizBuilder() {
            return {
                total: 60,
                sections: [
                    { type: 'Multiple Choice', count: 10 }
                ],
                addSection() {
                    this.sections.push({ type: 'Multiple Choice', count: 10 });
                },
                removeSection(index) {
                    this.sections.splice(index, 1);
                },
                get assignedQuestions() {
                    return this.sections.reduce((sum, section) => sum + (parseInt(section.count) || 0), 0);
                },
                get remainingQuestions() {
                    return this.total - this.assignedQuestions;
                }
            }
        }
    </script>
</x-app-layout>